/** Automatically generated file. DO NOT MODIFY */
package de.halfbit.pinnedsection.examples.pinnedsection;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}