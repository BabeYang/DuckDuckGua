Change Log
==========


Version 1.2.0 *(2014-02-17)*
----------------------------

 * Added support for custom Animations.
 * Added support for displaying Sticky notifications closed manually.
 * Allow to provide a custom parent.
 * Allow to provide a priority, so some urgent AppMsgs can jump to the front of the queue.
 * Fix: Activity leaking.


Version 1.1.1 *(2013-10-29)*
----------------------------

 * Update gradle build
 
 
Version 1.1.0 *(2013-10-08)*
----------------------------

 * Publish an aar file to Maven Central with Gradle.
 * Fix: Add missing piece to the build.gradle.
 * Fix: Updated the version of android-maven-plugin to build with the most recent Android SDK.


Version 1.0.1 *(2013-01-07)*
----------------------------

 * Formatting of the source code.
 * Bugfix.


Version 1.0.0 *(2012-12-23)*
----------------------------

Initial release.
